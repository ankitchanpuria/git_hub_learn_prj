def lambda_handler ():
    print ("copying from source to target")